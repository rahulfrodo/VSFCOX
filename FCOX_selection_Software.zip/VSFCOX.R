VSFCOX<-function(S,sdt,Xs,nbasis=10,p,K)
{
  n<-nrow(sdt)
  T<-list()
  for(i in 1:n)
  {
    T[[i]]<-S # dense and regular
  }
  # create basis
  norder = 4
  knots = seq(min(S),max(S),l=(nbasis-2))
  dayrng = c(min(S),max(S))
  library(fda)
  bbasis = create.bspline.basis(dayrng,nbasis,norder,knots)
  bbasisMat<-list()
  for (i in 1:n)
  {bbasisMat[[i]] = eval.basis(T[[i]],bbasis)}
  in.mat = inprod(bbasis,bbasis) # penalty matrix for function
  in.derivmat=inprod(bbasis,bbasis,int2Lfd(2),int2Lfd(2)) # penalty matrix for 2nd deriv.
  basismat<-bbasisMat
  for (i in 1:n){
    colnames(basismat[[i]])<-NULL}
  
  #group
  group<-c()
  for (j in 1:(p+K))
  {if(j<=p)
  {group[j]<-j}
    if(j>p) 
    {group[((nbasis*(j-p-1))+1+p):((nbasis*(j-p))+p)]<-j}
  }
  Groupvar<-as.factor(group)
  
  #Cholesky
  phiseq<-10^seq(-2,10,l=100)
  phi<-vector()
  R<-list()
  w<-1
  `%notin%` <- Negate(`%in%`)
  for (a in phiseq) {
    Kphi<-in.mat+a*in.derivmat
    t<-try(chol(Kphi), silent=TRUE)
    if("try-error" %notin% class(t)){
      R[[w]]<-chol(Kphi)
      phi[w]<-a
      w<-w+1
    }
  }
  library(matrixcalc)
  M<-list()
  w<-1
  phifinal<-vector()
  for (o in 1:length(R)) {
    if(!is.singular.matrix(R[[o]])){
      M[[w]]<-solve(R[[o]])
      phifinal[w]<-phi[o]
      w<-w+1
    }
  }
  
  sq<-c(1:length(M))
  
  # transformation of functional covariates into finite dimensions
  XMatstar<-list()
  for(i in 1:n)
  {XMatstar[[i]]<-array(0,dim=c(K,length(T[[i]]),nbasis))
  for (j in 1:K){
    for(l in 1:length(T[[i]])){
      datatempj<-Xs[[j]][i,]
      XMatstar[[i]][j,l,]=datatempj[l]*basismat[[i]][l,]
    }
  }
  }
  
  ZMatstar<-list()
  for(i in 1:n)
  {ZMatstar[[i]]<-array(0,dim=c(K,length(T[[i]]),nbasis))
  for (j in 1:K){
    for(l in 1:length(T[[i]])){
      ZMatstar[[i]][j,l,]=XMatstar[[i]][j,l,]
    }
  }
  }
  
  fc<-list()
  fcc<-NULL
  for (j in 1:K) {
    fc[[j]]<-array(0,dim=c(nbasis,n))
    for (q in 1:nbasis) {
      for (i in 1:n) {
        fc[[j]][q,i]<-mean(ZMatstar[[i]][j,,q])
      }
      
      fcc<-cbind(fcc,fc[[j]][q,])
    }
  }
  Z<-cbind(sdt,fcc)
  
  # calculate group-based dof
  dfree<-function(obj){
    j<-unlist(lapply(1:length(obj$lambda), function(i){
      gamma<-obj$beta[,i]
      indsel<-which(gamma!=0)
      Groupsel<-group[indsel]
      grind<-unique(Groupsel)
      return(length(grind))
    }))
    return(j)
  }
  
  #EBIC criterion
  slEBIC<-function(obj,p,j){
    ll <- logLik(obj)
    df <- as.double(attr(ll,"df"))
    d <- dim(obj$beta)
    IC = obj$deviance+log(obj$n)*j+ 2*(lgamma(p+1) - lgamma(j+1) - lgamma(p-j+1))
    
    n.l <- length(obj$lambda)
    i <- which.min(IC)
    
    return(list(beta=obj$beta[,i],
                lambda=obj$lambda[i],
                df=j,
                IC=IC))
  }
  
  # paralell computation
  library(parallel)
  ncores <-detectCores()-1
  cl <- makeCluster(ncores)
  cvphi<-function(w){
    fcnew<-list()
    fccnew<-NULL
    for (j in 1:K) {
      fcnew[[j]]<-array(0,dim=c(nbasis,n))
      for (i in 1:n) {
        fcnew[[j]][,i]<-fc[[j]][,i]%*%M[[w]]
      }
      for (q in 1:nbasis) {
        fccnew<-cbind(fccnew,fcnew[[j]][q,])
      }
    }
    Znew<-cbind(sdt[,-1],fccnew)
    
    fit3<-grpsurv(Znew,y,Groupvar,penalty="grMCP",lambda=seq(0.1,0.5,l=100))
    
    j<-dfree(fit3)
    EBICfit3<-slEBIC(fit3,p+K,j)
    
    gamma3<-EBICfit3$beta
    EBICmcp<-sort(EBICfit3$IC)[1]
    if(!is.finite(EBICmcp))
    {EBICmcp<-999999}
    lambdamcp<-EBICfit3$lambda
    cvresult<-list(EBICmcp,lambdamcp,gamma3,M[[w]])
    names(cvresult)<-c("EBICmcp","lambdamcp","gamma3","M")
    return(cvresult)
  }
  clusterExport(cl,c())
  clusterEvalQ(cl, library("grpreg"))
  clusterExport(cl, list("M","fc", "sdt","p","K","nbasis","n","y","group","Groupvar","slEBIC","dfree"), envir=environment())
  cvresultfinal<- parLapply(cl,sq,cvphi)
  stopCluster(cl)
  
  len<-length(sq)
  EBICm<-c()
  for (k in 1:len)  
  {
    EBICm<-c(EBICm,cvresultfinal[[k]]$EBICmcp) 
  }
  indmcp<-which.min(unlist(EBICm))
  gamma3<-cvresultfinal[[indmcp]]$gamma3
  Mmcp<-cvresultfinal[[indmcp]]$M
  psim<-phifinal[indmcp]
  ldm<-cvresultfinal[[indmcp]]$lambdamcp
  indsel3<-which(gamma3!=0)
  Groupsel3<-group[indsel3]
  grind3<-unique(Groupsel3)
  varselected3<-grind3
  
  scalar<-gamma3[1:p]
  
  temp3<-gamma3[-1:-p]
  M<-length(temp3)
  nt<-floor(M/nbasis)
  ind<-split(1:M,rep(1:nt,each=nbasis))
  g3<-lapply(ind, function(x){a<-temp3[x]})
  bmcp<-lapply(1:nt,function(x){Mmcp%*%g3[[x]]})
  btmcp<-lapply(1:nt,function(x){bbasisMat[[1]]%*%bmcp[[x]]})
  
  library(ggplot2)
  library(tidyr)
  library(dplyr)
  
  dtp<-list()
  plotstor<-list()
  for (i in 1:K) {
    dft <- data.frame(
      S = S,
      Beta1_t = betaf[[i]],
      btest = btmcp[[i]]
    )
    dtp[[i]] <- dft %>%
      pivot_longer(cols = -S, names_to = "Line", values_to = "Value") %>%
      mutate(LineType = case_when(
        Line == "Beta1_t" ~ "True",
        Line %in% c("btest") ~ "Estimated"
      ),
      Color = case_when(
        Line == "Beta1_t" ~ "True",
        Line %in% c("btest") ~ "Estimated"
      ))
    plotstor[[i]]<-ggplot(dtp[[i]], aes(x = S, y = Value)) +
      geom_line(aes(color = Color, linetype = LineType)) +
      scale_color_manual(
        values = c("True" = "black", "Estimated" = "blue"),
        name = "Type"
      ) +
      scale_linetype_manual(
        values = c("True" = "solid", "Estimated" = "dotted"),
        name = "Type"
      ) + 
      labs(x = "s", y = bquote(hat(beta)[.(i)] * "(·)")) +
      theme_minimal() +
      theme(
        legend.position = "right",
        axis.title.x = element_text(size = 15),  # Adjust x-axis title size
        axis.title.y = element_text(size = 15, angle = 0, vjust = 0.5, hjust = 0.5),  # Adjust y-axis title size
        axis.text = element_text(size = 15)      # Adjust axis tick labels size
      )
  }
  
  
  result<-list(varselected3,scalar,plotstor)
  names(result)<-c('selected variables','scalar parameters','functional parameters')
  return(result)
}