README.txt
===========

Title: Variable Selection in Functional Linear Cox Model (VSFCOX)

Overview:
---------
This project demonstrates the implementation of a variable selection method for the Functional Linear Cox Model (VSFCOX).

Files:
------
1. VSFCOX.R
   - This script defines the main function `VSFCOX()` for performing variable selection in the Functional Linear Cox Model.
   - The method handles data observed on a dense and regular grid.

2. FCOX_selection.Rmd
   - This R Markdown document provides a reproducible example illustrating how to use the `VSFCOX()` function with simulated toy data.
   - It walks through data generation, model fitting, and interpretation of results.
   - Includes steps to identify relevant scalar and functional covariates.

Dependencies:
-------------
The following R packages are required to run the code:
- `fda`
- `grpreg`
- `parallel`
- `matrixcalc`
- `ggplot2`
- `tidyr`
- `dplyr`

Usage:
------
1. Load the `VSFCOX.R` script into your R session:
   ```R
   source("VSFCOX.R")
   ```

2. Follow the example in `FCOX_selection.Rmd` to:
   - Simulate toy data with scalar and functional predictors.
   - Apply the `VSFCOX()` function.
   - Interpret the selected variables and coefficients.

Function Description:
---------------------
**VSFCOX(S, sdt, Xs, nbasis = 10, p, K)**

- `S` : Grid points.
- `sdt` : Data frame containing scalar covariates.
- `Xs` : List of functional covariates.
- `nbasis` : Number of B-spline basis functions to use.
- `p` : Number of scalar covariates.
- `K` : Number of functional covariates.

Output:
- A list containing:
  - `varselected3`: Indices of selected variables.
  - `coefficients`: Estimated coefficients for selected variables.

Citation:
---------
If you use this method in your work, please cite the original methodology as described in Yuanzhen’s work on variable selection for the Functional Linear Cox Model.

Contact:
--------
For questions or suggestions, please contact the author of the implementation or refer to the associated documentation.
